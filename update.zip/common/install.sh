
SYSPROP="$MODPATH"/system.prop; PERPROP="$MODPATH"/persist.prop; POSTFS="$MODPATH"/post-fs-data.sh; SERV="$MODPATH"/service.sh
